// src/components/WhiteDatePicker.tsx
import * as React from "react";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { TextField } from "@mui/material";

type DPProps = React.ComponentProps<typeof DatePicker<any>>;
type Props = Omit<DPProps, "slotProps"> & { slotProps?: DPProps["slotProps"] };

const merge = (a?: any, b?: any) => ({ ...(a || {}), ...(b || {}) });

export default function WhiteDatePicker({ slotProps, ...rest }: Props) {
  // En v6 el slot del campo es "field" (ya no "textField")
  const field = merge(
    {
      variant: "outlined",
      fullWidth: true,
      placeholder: "dd/mm/aaaa",
      InputProps: {
        sx: {
          // Fondo y bordes
          "& .MuiOutlinedInput-notchedOutline": { borderColor: "rgba(255,255,255,.6)" },
          "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#fff" },
          "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: "#fff" },
          backgroundColor: "rgba(15,23,42,.35)",
          borderRadius: "12px",

          // Texto y placeholder en blanco
          "& .MuiInputBase-input, & .MuiOutlinedInput-input": {
            color: "#fff !important",
            WebkitTextFillColor: "#fff",
          },
          "& input::placeholder, & .MuiInputBase-input::placeholder": {
            color: "rgba(255,255,255,.7) !important",
            opacity: 1,
          },

          // Ícono calendario
          "& .MuiSvgIcon-root": { color: "#fff" },

          // Autofill
          "& input:-webkit-autofill": {
            WebkitTextFillColor: "#fff",
            WebkitBoxShadow: "0 0 0 1000px rgba(15,23,42,.35) inset",
          },
        },
      },
      InputLabelProps: {
        sx: { color: "rgba(255,255,255,.85)", "&.Mui-focused": { color: "#fff" } },
      },
    },
    (slotProps as any)?.field
  );

  const popper = merge(
    {
      sx: {
        zIndex: 2100, // por encima del modal Tailwind (z-40/z-50)
        "& .MuiPaper-root": { backgroundColor: "#0f172a", color: "#fff" },
        "& .MuiPickersDay-root": { color: "#fff" },
        "& .MuiPickersDay-root.Mui-selected": { backgroundColor: "#6366f1", color: "#fff" },
        "& .MuiPickersCalendarHeader-label": { color: "#fff" },
        "& .MuiIconButton-root": { color: "#fff" },
        "& .MuiDayCalendar-weekDayLabel": { opacity: .85 },
        "& .MuiPickersDay-dayOutsideMonth, & .Mui-disabled": { opacity: .4 },
      },
      disablePortal: false, // render en body para evitar recortes
    },
    (slotProps as any)?.popper
  );

  return (
    <DatePicker
      {...rest}
      slots={{ field: TextField }}
      slotProps={{ ...slotProps, field, popper }}
    />
  );
}
